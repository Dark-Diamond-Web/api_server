const mongoose = require('mongoose');
const DailyEarningInfo = new mongoose.Schema({
    _id: mongoose.Schema.Types.ObjectId,
    AuthKey: String,
    SelectedPercentage: String,
    LatestUpdateDailyEarning: Date
})
module.exports = mongoose.model('DailyEarningInfo', DailyEarningInfo)
