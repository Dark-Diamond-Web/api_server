const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');
const User_data_model = require('../Model/user_data_model');
const Email_OTP_Verification = require('../Model/Email_OTP_verification');
const httpContext = require('express-http-context');
const nodemailer = require('nodemailer');
const moment = require('moment');
const bcrypt = require('bcrypt')

const cron = require('node-cron');


var transporter = nodemailer.createTransport({
    host: "smtpout.secureserver.net",
    port: 587,
    // secure: true,
    auth: {
        user: "info@arenafx.vip",
        pass: "Arenafx@24",
    },
    tls: {
        rejectUnauthorized: false,
    },
})

router.get('/UserData', (req, res, next) => {
    const AuthKey = httpContext.get("AuthKey");
    User_data_model.find({ _id: AuthKey })
        .select("-__v")
        .exec()
        .then(result => {
            res.status(200).json({
                UserData: result,
                status_Code: 200
            });
        })
        .catch(err => {
            res.status(500).json({
                error: err
            })
        })
})

router.post('/GetReferalDetails', (req, res, next) => {
    User_data_model.find({ Referral_Code: req.body.Referral_By })
        .select("-__v")
        .exec()
        .then(result => {
            res.status(200).json({
                ReferalDetails: result,
                status_Code: 200
            });
        })
        .catch(err => {
            res.status(500).json({
                error: err
            })
        })
})

router.post('/GetReferalData', (req, res, next) => {
    User_data_model.find({ Referral_By: req.body.Referral_Code })
        .select("-__v")
        .exec()
        .then(result => {
            let updatedResult = [];
            result.forEach(val => {
                // const Account_Type = val.Account_Type;
                let Percent = 0;
                let PercentAccordingToAccount = 0;
                Percent = val.Payment_Amount * 0.10;
                PercentAccordingToAccount = 10;
                // if (Account_Type === 'Pro') {
                //     Percent = val.Payment_Amount * 0.12;
                //     PercentAccordingToAccount = 12;
                // } 
                // else if (Account_Type === 'Lite') {
                //     Percent = val.Payment_Amount * 0.08;
                //     PercentAccordingToAccount = 8;
                // } 

                const formattedAccountCreatedTime = moment(val.Account_Created_Time).format('YYYY-MM-DD HH:mm:ss');
                updatedResult.push({
                    ...val._doc,
                    Modified_Percent_Payment_Amount: Percent,
                    PercentAccordingToAccount: PercentAccordingToAccount,
                    Formatted_Account_Created_Time: formattedAccountCreatedTime
                });
            });
            res.status(200).json({
                ReferalDetails: updatedResult,
                status_Code: 200
            });
        })
        .catch(err => {
            res.status(500).json({
                error: err
            });
        });
});


// Update 
router.put('/UpdatePayment/:_id', (req, res, next) => {
    User_data_model.findOneAndUpdate({ _id: req.params._id }, {
        $set: {
            Payment_Status: 'Pending',
            Payment_Prof: req.body.Payment_Prof,
            Account_Type: req.body.Account_Type,
            Payment_Amount: req.body.Payment_Amount,
            Payment_Approve_Date: Date.now(),
        }
    })
        .then(result => {
            res.status(200).json({
                Updated: result,
                Status_Code: 200
            })
            var mailOptions = {
                from: '"Arena FX" <info@arenafx.vip>',
                to: `${result.Email_ID}`,
                subject: 'Payment Approval Notification – Please Allow 24 Hours',
                html: `<p>Dear <strong>${result.First_Name} !</strong></p> <br>
                <p>Thank you for your recent payment submission to Arena FX.</p><br>
                <p>We are currently processing your payment, and this process typically takes up to 24 hours to complete. We appreciate your patience as we ensure that all transactions are secure and verified for your protection.</p>
                <p>Rest assured, you will receive a confirmation email once your payment has been successfully approved. In the meantime, if you have any questions or require further assistance, please do not hesitate to contact our support team at support@arenaFX.com.</p><br>
                <p>Thank you for your understanding and for choosing Arena FX.</p><br>
                <p>Best regards,</p>
                <p>Customer Support Team</p>
                <p>Arena FX</p> 
                `
            }
            transporter.sendMail(mailOptions, function (error, info) {
                if (error) {
                }
                else {
                    // console.log('verification Sent!!!!')
                }
            })
            var mailOptions = {
                from: '"Arena FX" <info@arenafx.vip>',
                to: "sonusilent.iimt@gmail.com",
                subject: 'Payment Approval Request',
                html: `<p>Dear <strong>Team !</strong></p>
                <p>We got new Payment Request from ${result.First_Name}</p>
                <p>Name:- ${result.First_Name} ${result.Last_Name}</p>
                <p>Email:- ${result.Email_ID}</p>
                <p>Referral Code:- ${result.Referral_Code}</p>
                <p>Account Type:- ${result.Account_Type}</p>
                <p>Payment Amount:- ${result.Payment_Amount}</p>
                `
            }
            transporter.sendMail(mailOptions, function (error, info) {
                if (error) {
                }
                else {
                    // console.log('verification Sent!!!!')
                }
            })
        })
        .catch(err => {
            // console.log(err);
            res.status(500).json({
                error: err
            })
        })
})

router.post('/Authenticate_User', async (req, res, next) => {
    try {
        const AuthKey = httpContext.get("AuthKey");
        const user = await User_data_model.findOne({ _id: AuthKey, Email_ID: req.body.Email_ID }).select("-__v").exec();

        if (!user) {
            return res.status(200).json({
                message: "Something went wrong!",
                Status_Code: 300
            });
        }

        const emailOTPRecords = await Email_OTP_Verification.find({ Email_ID: req.body.Email_ID }).exec();

        if (emailOTPRecords.length > 0) {
            await Email_OTP_Verification.remove({ Email_ID: req.body.Email_ID }).exec();
        }

        // Send OTP verification email
        await SendOTPVerificationEmail(req.body.Email_ID, user.First_Name);

        res.status(200).json({
            message: "OTP has been sent successfully!!",
            Status_Code: 200
        });
    } catch (err) {
        res.status(500).json({
            error: err.message
        });
    }
});

const SendOTPVerificationEmail = async (Email_ID, Name) => {
    try {
        const otp = `${Math.floor(9000 + Math.random() * 1000)}`;
        const mailOptions = {
            from: '"Arena FX" <info@arenafx.vip>',
            to: Email_ID,
            subject: 'Your One-Time Password (OTP) for Arena FX',
            html: `
            <p>Dear <strong>${Name} !</strong> </p> 
            <p>For your security, we have generated a One-Time Password (OTP) to complete your recent action on Arena FX. Please use the OTP below to proceed:</p>
            <p>Your OTP:-<strong style="color:#1A2D4A; font-size:20px; font-weight:700;"> ${otp}</strong></p>
            <p>This OTP is valid for the next 2 minutes. If you did not request this OTP, please contact our support team immediately.</p><br>
            <p>To ensure the security of your account, do not share this OTP with anyone. Arena FX will never ask you for your password or OTP.</p>
            <p>If you have any questions or need further assistance, feel free to contact us at support@arenaFX.com.</p><br>
            <p>Thank you for choosing Arena FX.</p><br>
            <p>Best regards,</p>
            <p>Customer Support Team </p>
            <p>Arena FX VIP</p>
            `
        };
        const saltRounds = 2;
        const hashedOTP = await bcrypt.hash(otp, saltRounds);
        const emailOTPVerification = new Email_OTP_Verification({
            _id: new mongoose.Types.ObjectId,
            Email_ID: Email_ID,
            otp: hashedOTP,
            CreatedTime: Date.now(),
            ExpiredTime: Date.now() + 120000,
        });
        await emailOTPVerification.save();
        await transporter.sendMail(mailOptions);
    } catch (error) {
        console.error("Failed to send OTP email:", error.message);
        throw error; // Propagate the error to the caller
    }
};

// router.post('/Authenticate_User', (req, res, next) => {
//     const AuthKey = httpContext.get("AuthKey");
//     User_data_model.find({ _id: AuthKey, Email_ID: req.body.Email_ID })
//         .select("-__v")
//         .exec()
//         .then(result => {
//             const Name = result[0].First_Name;
//             if (result.length !== 0) {
//                 Email_OTP_Verification.find({ Email_ID: req.body.Email_ID })
//                     .exec()
//                     .then(result => {
//                         if (result.length !== 0) {
//                             Email_OTP_Verification.remove({ Email_ID: req.body.Email_ID })
//                                 .then(result => {
//                                     const Email_ID = req.body.Email_ID;
//                                     // const Name = req.body.First_Name;
//                                     SendOTPVerificationEmail(Email_ID, Name)
//                                     res.status(200).json({
//                                         message: "OTP has been sent successfully!!",
//                                         Status_Code: 200
//                                     });
//                                 })
//                         }
//                         if (result.length == 0) {
//                             const Email_ID = req.body.Email_ID;
//                             const Name = req.body.First_Name;
//                             SendOTPVerificationEmail(Email_ID, Name)
//                             res.status(200).json({
//                                 message: "OTP has been sent successfully!!",
//                                 Status_Code: 200
//                             });
//                         }
//                     })
//             }
//             if (result.length == 0) {
//                 res.status(200).json({
//                     message: "Something went wrong!",
//                     Status_Code: 300
//                 });
//             }
//         })
//         .catch(err => {
//             res.status(500).json({
//                 error: err
//             })
//         })
// })

// const SendOTPVerificationEmail = async (Email_ID, Name, res) => {
//     try {
//         const otp = `${Math.floor(9000 + Math.random() * 1000)}`;
//         const mailOptions = {
//             from: '"Arena FX" <info@arenafx.vip>',
//             to: Email_ID,
//             subject: 'Your One-Time Password (OTP) for Arena FX',
//             html: `
//             <p>Dear <strong>${Name} !</strong> </p> 
//             <p>For your security, we have generated a One-Time Password (OTP) to complete your recent action on Arena FX. Please use the OTP below to proceed:</p>
//             <p>Your OTP:-<strong style="color:#1A2D4A; font-size:20px; font-weight:700;"> ${otp}</strong></p>
//             <p>This OTP is valid for the next 2 minutes. If you did not request this OTP, please contact our support team immediately.</p><br>
//             <p>To ensure the security of your account, do not share this OTP with anyone. Arena FX will never ask you for your password or OTP.</p>
//             <p>If you have any questions or need further assistance, feel free to contact us at support@arenaFX.com.</p><br>
//             <p>Thank you for choosing Arena FX.</p><br>
//             <p>Best regards,</p>
//             <p>Customer Support Team </p>
//             <p>Arena FX VIP</p>
//             `
//         };
//         const saltRounds = 2;
//         const hashedOTP = await bcrypt.hash(otp, saltRounds);
//         const email_OTP_Verification = await Email_OTP_Verification({
//             _id: new mongoose.Types.ObjectId,
//             Email_ID: Email_ID,
//             otp: hashedOTP,
//             CreatedTime: Date.now(),
//             ExpiredTime: Date.now() + 120000,
//         });
//         await email_OTP_Verification.save();
//         await transporter.sendMail(mailOptions);
//     }
//     catch (error) {
//         res.json({
//             status: "Failed",
//             message: error.message,
//         });
//     }
// }

router.put('/ActivateDailyEarning/:_id', (req, res, next) => {
    User_data_model.findOneAndUpdate({ _id: req.params._id }, {
        $set: {
            Activate_AI_Boat_Status: "Activated",
            Activate_AI_Boat_Date: new Date(),
        }
    })
        .then(result => {
            res.status(200).json({
                Updated: result,
                Status_Code: 200
            });
        })
        .catch(err => {
            // console.log(err);
            res.status(500).json({
                error: err
            });
        });
});


// async function updateDailyEarningAmount() {
//     try {
//         const users = await User_data_model.find({ Activate_AI_Boat_Status: "Activated" }); 
//         for (let i = 0; i < users.length; i++) {
//             const user = users[i];
//             const updatedAmount = user.Payment_Amount * 0.005;
//             user.Daily_Earning_Amount = user.Daily_Earning_Amount + updatedAmount;

//             await user.save();
//             console.log(`Updated Daily_Earning_Amount for ${user.First_Name} ${user.Last_Name}`);
//         }
//     } catch (err) {
//         console.error('Error updating Daily_Earning_Amount:', err);
//     }
// }

// cron.schedule('1 0 * * 1-5', () => {
//     console.log('Running daily earning update task...');
//     updateDailyEarningAmount();
// });











// User_data_model.find({ Payment_Status: "Approved" })
//     .select("-__v, -Payment_Prof")
//     .exec()
//     .then(result => {
//         console.log(result)

//         for (let i = 0; i < result.length; i++) {
//             const First_level_Target = result[i].Level_One_Referal;

//             console.log(First_level_Target);
//         }
//     })
//     .catch(err => {
//         console.log(err)
//     })



// router.get('/approved-users', async (req, res) => {
//     try {
//         // Find users with Payment_Status: "Approved"
//         const approvedUsers = await User_data_model.find({ Payment_Status: "Approved" })
//         .select("-__v -Payment_Prof")
//         .exec();
//         const referralsDetails = [];
//         // Loop through each approved user
//         for (let i = 0; i < approvedUsers.length; i++) {
//             const user = approvedUsers[i];
//             const firstLevelReferrals = user.Level_One_Referal;
//             if (firstLevelReferrals.length > 0) {
//                 // Find details of each referral in Level_One_Referal
//                 const referrals = await User_data_model.find({ Referral_Code: { $in: firstLevelReferrals } })
//                 .select("-__v -Payment_Prof")
//                 .exec()
//                 referralsDetails.push({
//                     user: user,
//                     referrals: referrals
//                 });
//             } else {
//                 referralsDetails.push({
//                     user: user,
//                     referrals: []
//                 });
//             }
//         }
//         res.json(referralsDetails);
//     } catch (err) {
//         console.error(err);
//         res.status(500).send('Internal Server Error');
//     }
// });
 


// router.get('/approved-users', async (req, res) => {
//     try {
//         // Find users with Payment_Status: "Approved"
//         const approvedUsers = await User_data_model.find({ Payment_Status: "Approved" })
//             .select("-__v -Payment_Prof")
//             .exec();
//         const referralsDetails = [];

//         // Loop through each approved user
//         for (let i = 0; i < approvedUsers.length; i++) {
//             const user = approvedUsers[i];
//             const firstLevelReferrals = user.Level_One_Referal;
//             let totalLevelIncome = 0;

//             if (firstLevelReferrals.length > 0) {
//                 // Find details of each referral in Level_One_Referal
//                 const referrals = await User_data_model.find({ Referral_Code: { $in: firstLevelReferrals } })
//                     .select("-__v -Payment_Prof")
//                     .exec();
                
//                 referrals.forEach(referral => {
//                     if (referral.Payment_Status === "Approved") {
//                         totalLevelIncome += referral.Payment_Amount * 0.025;
//                     }
//                 });

//                 referralsDetails.push({
//                     user: { ...user.toObject(), Level_Income: totalLevelIncome },
//                     referrals: referrals
//                 });
//             } else {
//                 referralsDetails.push({
//                     user: { ...user.toObject(), Level_Income: totalLevelIncome },
//                     referrals: []
//                 });
//             }
//         }
        
//         res.json(referralsDetails);
//     } catch (err) {
//         console.error(err);
//         res.status(500).send('Internal Server Error');
//     }
// });






// async function updateLevelIncome() {
//     try {
//         // Find users with Payment_Status: "Approved"
//         const approvedUsers = await User_data_model.find({ Payment_Status: "Approved" })
//             .select("-__v -Payment_Prof")
//             .exec();

//         // Loop through each approved user
//         for (let i = 0; i < approvedUsers.length; i++) {
//             const user = approvedUsers[i];
//             const firstLevelReferrals = user.Level_One_Referal;
//             const secondLevelReferrals = user.Level_Two_Referal;
//             const thirdLevelReferrals = user.Level_Three_Referal;
            
//             let totalLevelIncome = 0;

//             // Calculate income from Level One Referrals
//             if (firstLevelReferrals.length > 0) {
//                 const referrals = await User_data_model.find({ Referral_Code: { $in: firstLevelReferrals } })
//                     .select("-__v -Payment_Prof")
//                     .exec();
                
//                 referrals.forEach(referral => {
//                     if (referral.Payment_Status === "Approved") {
//                         totalLevelIncome += referral.Payment_Amount * 0.025;
//                     }
//                 });
//             }

//             // Calculate income from Level Two Referrals
//             if (secondLevelReferrals.length > 0) {
//                 const referrals = await User_data_model.find({ Referral_Code: { $in: secondLevelReferrals } })
//                     .select("-__v -Payment_Prof")
//                     .exec();
                
//                 referrals.forEach(referral => {
//                     if (referral.Payment_Status === "Approved") {
//                         totalLevelIncome += referral.Payment_Amount * 0.015;
//                     }
//                 });
//             }

//             // Calculate income from Level Three Referrals
//             if (thirdLevelReferrals.length > 0) {
//                 const referrals = await User_data_model.find({ Referral_Code: { $in: thirdLevelReferrals } })
//                     .select("-__v -Payment_Prof")
//                     .exec();
                
//                 referrals.forEach(referral => {
//                     if (referral.Payment_Status === "Approved") {
//                         totalLevelIncome += referral.Payment_Amount * 0.01;
//                     }
//                 });
//             }

//             // Add calculated Level_Income to the existing amount
//             user.Level_Income += totalLevelIncome;
//             await user.save();
//         }
//     } catch (err) {
//         console.error('Error updating Level_Income:', err);
//     }
// }

// // Schedule the update function to run every day at 9:42 PM
// cron.schedule('10 22 * * *', () => {
//     console.log('Running Level_Income update at 9:42 PM');
//     updateLevelIncome();
// });

 

async function updateLevelIncome() {
    try {
        // Find users with Payment_Status: "Approved"
        const approvedUsers = await User_data_model.find({ Payment_Status: "Approved" })
            .select("-__v -Payment_Prof")
            .exec();

        // Loop through each approved user
        for (let i = 0; i < approvedUsers.length; i++) {
            const user = approvedUsers[i];
            const firstLevelReferrals = user.Level_One_Referal;
            const secondLevelReferrals = user.Level_Two_Referal;
            const thirdLevelReferrals = user.Level_Three_Referal;

            // Check if the user's Payment_Approve_Date is older than one month
            if (moment().diff(moment(user.Payment_Approve_Date), 'months') >= 1) {
                let totalLevelIncome = 0;

                // Calculate income from Level One Referrals
                if (firstLevelReferrals.length > 0) {
                    const referrals = await User_data_model.find({ Referral_Code: { $in: firstLevelReferrals } })
                        .select("-__v -Payment_Prof")
                        .exec();
                    
                    referrals.forEach(referral => {
                        if (referral.Payment_Status === "Approved") {
                            totalLevelIncome += referral.Payment_Amount * 0.025;
                        }
                    });
                }

                // Calculate income from Level Two Referrals
                if (secondLevelReferrals.length > 0) {
                    const referrals = await User_data_model.find({ Referral_Code: { $in: secondLevelReferrals } })
                        .select("-__v -Payment_Prof")
                        .exec();
                    
                    referrals.forEach(referral => {
                        if (referral.Payment_Status === "Approved") {
                            totalLevelIncome += referral.Payment_Amount * 0.015;
                        }
                    });
                }

                // Calculate income from Level Three Referrals
                if (thirdLevelReferrals.length > 0) {
                    const referrals = await User_data_model.find({ Referral_Code: { $in: thirdLevelReferrals } })
                        .select("-__v -Payment_Prof")
                        .exec();
                    
                    referrals.forEach(referral => {
                        if (referral.Payment_Status === "Approved") {
                            totalLevelIncome += referral.Payment_Amount * 0.01;
                        }
                    });
                }

                // Add calculated Level_Income to the existing amount
                user.Level_Income += totalLevelIncome;
                await user.save();
            }
        }
    } catch (err) {
        console.error('Error updating Level_Income:', err);
    }
}

// Schedule the update function to run every day at 9:42 PM
cron.schedule('21 23 * * *', () => {  // Adjusted cron time to 21:42 (9:42 PM)
    console.log('Running Level_Income update at 9:42 PM');
    updateLevelIncome();
});


module.exports = router; 