const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');
const AdminData = require('../Model/admin')
const Email_OTP_Verification = require('../Model/Email_OTP_verification');
const jwt = require('jsonwebtoken')
const nodemailer = require('nodemailer');
const bcrypt = require('bcrypt')

var transporter = nodemailer.createTransport({
    host: "smtpout.secureserver.net",
    port: 587,
    // secure: true,
    auth: {
        user: "info@arenafx.vip",
        pass: "Arenafx@24",
    },
    tls: {
        rejectUnauthorized: false,
    },
})

router.post('/GenerateOTP', (req, res, next) => {
    AdminData.find({ Email_ID: req.body.Email_ID.toLowerCase() })
        .select("-__v")
        .exec()
        .then(result => {
            if (result.length !== 0) {
                res.status(200).json({
                    message: "Email ID already registred",
                    Status_Code: 300
                });
            }
            if (result.length == 0) {
                Email_OTP_Verification.find({ Email_ID: req.body.Email_ID.toLowerCase() })
                    .exec()
                    .then(result => {
                        if (result.length !== 0) {
                            Email_OTP_Verification.remove({ Email_ID: req.body.Email_ID.toLowerCase() })
                                .then(result => {
                                    const Email_ID = req.body.Email_ID.toLowerCase();
                                    const Name = req.body.First_Name;
                                    SendOTPVerificationEmail(Email_ID, Name)
                                    res.status(200).json({
                                        message: "OTP has been sent successfully!!",
                                        Status_Code: 200
                                    });
                                })
                        }
                        if (result.length == 0) {
                            const Email_ID = req.body.Email_ID.toLowerCase();
                            const Name = req.body.First_Name;
                            SendOTPVerificationEmail(Email_ID, Name)
                            res.status(200).json({
                                message: "OTP has been sent successfully!!",
                                Status_Code: 200
                            });
                        }
                    })
            }
        })
        .catch(err => {
            // console.log(err);
            res.status(500).json({
                error: err
            })
        })
})

const SendOTPVerificationEmail = async (Email_ID, Name, res) => {
    try {
        const otp = `${Math.floor(9000 + Math.random() * 1000)}`;
        const mailOptions = {
            from: '"Arena FX" <info@arenafx.vip>',
            to: Email_ID,
            subject: 'Email OTP verificartion',
            html: `
            <p>Dear <strong>${Name}</strong> </p> 
            <p>OTP:-<strong style="color:#1A2D4A; font-size:20px; font-weight:700;"> ${otp}</strong></p>
            <p>Note: This OTP is valid for 2min only.</p>
            <p>Have a great day!</p>
            `
        };
        const saltRounds = 2;
        const hashedOTP = await bcrypt.hash(otp, saltRounds);
        const email_OTP_Verification = await Email_OTP_Verification({
            _id: new mongoose.Types.ObjectId,
            Email_ID: Email_ID,
            otp: hashedOTP,
            CreatedTime: Date.now(),
            ExpiredTime: Date.now() + 120000,
        });
        await email_OTP_Verification.save();
        await transporter.sendMail(mailOptions);
    }
    catch (error) {
        res.json({
            status: "Failed",
            message: error.message,
        });
    }
}

router.post("/Verify_OTP", async (req, res) => {
    try {
        const Email_ID = req.body.Email_ID.toLowerCase();
        const otp = req.body.otp;
        if (!Email_ID || !otp) {
            throw Error("Empty OTP Details are not Allowed!")
        } else {
            const email_OTP_Verification = await Email_OTP_Verification.find({
                Email_ID,
            });
            if (email_OTP_Verification.length <= 0) {
                throw new Error(
                    "OTP has been verified already!"
                );
            } else {
                const { ExpiredTime } = email_OTP_Verification[0];
                const hashedOTP = email_OTP_Verification[0].otp;

                if (ExpiredTime < Date.now()) {
                    await Email_OTP_Verification.deleteMany({ Email_ID });
                    throw new Error("OTP Expired. Please request again");
                } else {
                    const validOTP = await bcrypt.compare(otp, hashedOTP);

                    if (!validOTP) {
                        throw new Error("Invalid Code Passed. Check Again");
                    } else {
                        await Email_OTP_Verification.updateOne({ Email_ID: Email_ID }, { verified: true });
                        await Email_OTP_Verification.deleteMany({ Email_ID });
                        res.status(200).json({
                            message: "OTP has been verified successfully!!",
                            Status_Code: 200
                        });
                    }
                }
            }
        }
    } catch (error) {
        res.json({
            status: "Failed",
            message: error.message,
            Status_Code: 300
        })
    }
});

router.post('/create_user', async (req, res, next) => {
    bcrypt.hash(req.body.Create_Password, 10, (err, hash) => {
        if (err) {
            return res.status(500).json({
                error: err
            })
        }
        else {
            const adminData = new AdminData({
                _id: new mongoose.Types.ObjectId,
                First_Name: req.body.First_Name,
                Last_Name: req.body.Last_Name,
                Email_ID: req.body.Email_ID.toLowerCase(),
                password: hash,
                Account_Created_Time: new Date(),
            })
            adminData.save()
                .then(result => {
                    res.status(200).json({
                        message: "Registration Success!!",
                        status_coe: 200
                    })
                })
                .catch(err => {
                    // console.log(err);
                    res.status(500).json({
                        error: err
                    })
                })
            var mailOptions = {
                from: '"Arena FX" <info@arenafx.vip>',
                to: adminData.Email_ID,
                subject: 'New Admin Successfully',
                html: `<p>Dear <strong>${adminData.First_Name} !</strong></p>
                <p>User ID <strong>${adminData.Email_ID}</strong></p>
                <p>Password <strong>${req.body.Create_Password}</strong></p>
                 `
            }
            transporter.sendMail(mailOptions, function (error, info) {
                if (error) {
                    // console.log(error)
                }
                else {
                    console.log('verification Sent!!!!')
                }
            })
        }
    })
})

router.post('/login', (req, res, next) => {
    AdminData.find({ Email_ID: req.body.Email_ID.toLowerCase() })
        .exec()
        .then(user => {
            if (user.length < 1) {
                return res.status(200).json({
                    message: 'invalid Credentials!',
                    status_code: 404
                })
            }
            bcrypt.compare(req.body.password, user[0].password, (err, result) => {
                if (!result) {
                    return res.status(200).json({
                        message: 'invalid Credentials!',
                        status_code: 404
                    })
                }
                if (result) {
                    const token = jwt.sign({
                        AuthKey: user[0]._id,
                        status_code: 200
                    },
                        'User Details',
                        {
                            expiresIn: "12h"
                        }
                    );
                    res.status(200).json({
                        token: token,
                        status_code: 200
                    })
                }
            })
        })
        .catch(err => {
            res.status(500).json({
                err: err
            })
        })
})


module.exports = router; 