const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');
const PaymentRequest = require('../Model/payment_request');
const httpContext = require('express-http-context');
const moment = require('moment');
const nodemailer = require('nodemailer');

var transporter = nodemailer.createTransport({
    host: "smtpout.secureserver.net",
    port: 587,
    // secure: true,
    auth: {
        user: "info@arenafx.vip",
        pass: "Arenafx@24",
    },
    tls: {
        rejectUnauthorized: false,
    },
})

router.post('/registerRequest', (req, res, next) => {
    const AuthKey = httpContext.get("AuthKey");
    const Email = req.body.Email_ID;
    const First_Name = req.body.First_Name;
    const wallet_Amount = req.body.wallet_Amount;
    const paymentRequest = new PaymentRequest({
        _id: new mongoose.Types.ObjectId,
        First_Name: req.body.First_Name,
        Last_Name: req.body.Last_Name,
        Email_ID: req.body.Email_ID,
        wallet_Amount: req.body.wallet_Amount,
        wallet_Account: req.body.wallet_Account,
        PaymentType: req.body.PaymentType,
        Payment_Status: 'Pending',
        RequestTime: new Date(),
        AuthKey: AuthKey 
    })
    paymentRequest.save()
        .then(result => {
            res.status(200).json({
                Message: result,
                Status_Code: 200
            })
            var mailOptions = {
                from: '"Arena FX" <info@arenafx.vip>',
                to: `${Email}`,
                subject: 'Payment Confirmation – Your Payment Request Successful Sent!',
                html: `<p>Dear <strong>${First_Name} !</strong></p> <br>
                <p>We are pleased to inform you that your payment to Arena FX has been successfully processed.</p><br>
                <p><strong>Payment Details:</strong> </p>
                <p>Amount: <strong>${wallet_Amount}</strong> </p> 
                <br>
                <p>Your account has been credited accordingly, and you can now continue to enjoy our forex trading services without interruption.</p>
                <p>If you have any questions or need further assistance, please do not hesitate to contact our support team at support@arenaFX.com.</p><br>
                <p>Thank you for choosing Arena FX. We appreciate your trust and look forward to supporting your trading journey.</p><br>
                <br>
                <p>Best regards,</p>
                <p>Customer Support Team</p>
                <p>Arena FX</p> 
                `
            }
            transporter.sendMail(mailOptions, function (error, info) {
                if (error) {
                }
                else {
                    // console.log('verification Sent!!!!')
                }
            }) 
        })
        .catch(err => { 
            res.status(500).json({
                error: err
            })
        })
});

router.get('/GetRequest', (req, res, next) => {
    const AuthKey = httpContext.get("AuthKey");
    PaymentRequest.find({ AuthKey: AuthKey })
        .select("-__v")
        .exec()
        .then(result => {
            const updatedResult = result.map(item => {
                const RequestTime = moment(item.RequestTime).format('YYYY-MM-DD HH:mm:ss');
                return {
                    ...item._doc,
                    RequestTime: RequestTime
                };
            });
            res.status(200).json({
                PaymentRequest: updatedResult,
                Status_Code: 200
            });
        })
        .catch(err => { 
            res.status(500).json({
                error: err
            })
        })
})

module.exports = router; 